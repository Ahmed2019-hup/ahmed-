The new information is not explicitly used by the system until you install
another module that makes use of it, e.g. RMA Claim (Product Return
Management).
