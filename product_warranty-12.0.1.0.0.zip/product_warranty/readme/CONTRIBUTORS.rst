* Emmanuel Samyn <esamyn@gmail.com>
* Paulius Sladkevičius <paulius@inovera.lt>
* Benoît Guillot <benoit.guillot@akretion.com.br>
* David Beal <david.beal@akretion.com>
* Maxime Chambreuil <maxime.chambreuil@savoirfairelinux.com>
* Joël Grand-Guillaume <joel.grandguillaume@gmail.com>
* Ondřej Kuzník <ondrej.kuznik@credativ.co.uk>
* Yanina Aular <yanina.aular@vauxoo.com>
* Cyril Gaudin <cyril.gaudin@camptocamp.com>
* Bima Jati Wijaya <bimajatiwijaya@gmail.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
