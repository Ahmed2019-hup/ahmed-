Extends the product warranty management with warranty details on product /
supplier relation:

* Supplier warranty duration
* Set default return address for company (if different from standard one)
* Whether to return product to company, supplier, other
